import React, { Children } from 'react';
import { motion } from 'framer-motion';
export function HeroSection() {
  const containerVariants = {
    hidden: {
      opacity: 0
    },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.2,
        delayChildren: 0.3
      }
    }
  };
  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 30
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: [0.25, 0.1, 0.25, 1]
      }
    }
  };
  return (
    <section className="relative h-screen w-full flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src="https://images.unsplash.com/photo-1596462502278-27bfdc403348?auto=format&fit=crop&q=80&w=2000"
          alt="Luxury beauty textures"
          className="w-full h-full object-cover object-center" />

        <div className="absolute inset-0 bg-cream/40 backdrop-blur-[2px]"></div>
        <div className="absolute inset-0 bg-gradient-to-b from-cream/60 via-transparent to-cream"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 max-w-5xl mx-auto px-6 text-center mt-20">
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="flex flex-col items-center">

          <motion.span
            variants={itemVariants}
            className="text-sm md:text-base uppercase tracking-[0.3em] text-rose mb-6 font-medium">

            A New Era of Aesthetics
          </motion.span>

          <motion.h1
            variants={itemVariants}
            className="text-5xl md:text-7xl lg:text-8xl font-serif text-charcoal leading-[1.1] mb-8">

            Investing in the <br className="hidden md:block" />
            <span className="italic text-rose">Future</span> of Beauty
          </motion.h1>

          <motion.p
            variants={itemVariants}
            className="text-lg md:text-xl text-charcoal/80 max-w-2xl mx-auto mb-12 font-light leading-relaxed">

            We partner with visionary founders to build the next generation of
            iconic, enduring luxury beauty and wellness brands.
          </motion.p>

          <motion.div variants={itemVariants}>
            <a
              href="#about"
              className="inline-flex items-center justify-center px-8 py-4 bg-charcoal text-cream uppercase tracking-widest text-sm hover:bg-rose transition-colors duration-500 border border-transparent hover:border-rose group">

              Discover Our Vision
              <span className="ml-3 w-8 h-[1px] bg-gold group-hover:w-12 transition-all duration-500"></span>
            </a>
          </motion.div>
        </motion.div>
      </div>
    </section>);

}