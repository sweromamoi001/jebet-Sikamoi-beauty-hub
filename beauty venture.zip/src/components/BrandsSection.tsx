import React, { Children } from 'react';
import { motion } from 'framer-motion';
const brands = [
{
  name: 'AURA BOTANICA',
  category: 'Skincare',
  image:
  'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800'
},
{
  name: 'MAISON NOIR',
  category: 'Fragrance',
  image:
  'https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&q=80&w=800'
},
{
  name: 'LUMIÈRE',
  category: 'Color Cosmetics',
  image:
  'https://images.unsplash.com/photo-1586495777744-4413f21062fa?auto=format&fit=crop&q=80&w=800'
},
{
  name: 'VERDANT',
  category: 'Wellness',
  image:
  'https://images.unsplash.com/photo-1608248543803-ba4f8c70ae0b?auto=format&fit=crop&q=80&w=800'
},
{
  name: 'ÉCLAT',
  category: 'Haircare',
  image:
  'https://images.unsplash.com/photo-1617897903246-719242758050?auto=format&fit=crop&q=80&w=800'
},
{
  name: 'RITUAL',
  category: 'Body Care',
  image:
  'https://images.unsplash.com/photo-1608248593842-8021b61f8719?auto=format&fit=crop&q=80&w=800'
}];

export function BrandsSection() {
  const containerVariants = {
    hidden: {
      opacity: 0
    },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.15
      }
    }
  };
  const itemVariants = {
    hidden: {
      opacity: 0,
      y: 40
    },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        duration: 0.8,
        ease: 'easeOut'
      }
    }
  };
  return (
    <section id="portfolio" className="py-24 md:py-32 bg-white">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="text-center mb-16 md:mb-24">
          <span className="text-xs uppercase tracking-[0.2em] text-rose mb-4 block">
            Selected Works
          </span>
          <h2 className="text-4xl md:text-5xl font-serif text-charcoal">
            Our Portfolio
          </h2>
        </div>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          whileInView="visible"
          viewport={{
            once: true,
            margin: '-100px'
          }}
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8 md:gap-12">

          {brands.map((brand, index) =>
          <motion.div
            key={brand.name}
            variants={itemVariants}
            className="group cursor-pointer">

              <div className="relative aspect-[4/5] overflow-hidden mb-6 bg-pink">
                <img
                src={brand.image}
                alt={brand.name}
                className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" />

                <div className="absolute inset-0 bg-charcoal/0 group-hover:bg-charcoal/10 transition-colors duration-500"></div>
              </div>
              <div className="text-center">
                <h3 className="font-serif text-xl text-charcoal mb-2">
                  {brand.name}
                </h3>
                <p className="text-sm uppercase tracking-widest text-charcoal/50">
                  {brand.category}
                </p>
              </div>
            </motion.div>
          )}
        </motion.div>

        <div className="mt-20 text-center">
          <a
            href="#"
            className="inline-block border-b border-charcoal pb-1 text-sm uppercase tracking-widest text-charcoal hover:text-rose hover:border-rose transition-colors duration-300">

            View Full Portfolio
          </a>
        </div>
      </div>
    </section>);

}