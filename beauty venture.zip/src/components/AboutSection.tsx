import React from 'react';
import { motion } from 'framer-motion';
export function AboutSection() {
  return (
    <section id="about" className="py-24 md:py-32 bg-cream">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          {/* Text Content */}
          <motion.div
            initial={{
              opacity: 0,
              x: -30
            }}
            whileInView={{
              opacity: 1,
              x: 0
            }}
            viewport={{
              once: true,
              margin: '-100px'
            }}
            transition={{
              duration: 0.8,
              ease: 'easeOut'
            }}
            className="lg:col-span-5 lg:col-start-2 order-2 lg:order-1">

            <h2 className="text-4xl md:text-5xl font-serif text-charcoal mb-8 leading-tight">
              Where Vision <br />
              <span className="italic text-rose">Meets Beauty</span>
            </h2>
            <div className="space-y-6 text-charcoal/80 font-light leading-relaxed">
              <p>
                Beauté Ventures is a premier investment firm dedicated
                exclusively to the luxury beauty, skincare, and wellness
                sectors. We believe that true beauty innovation requires more
                than just capital—it requires deep industry expertise, strategic
                foresight, and an unwavering commitment to craft.
              </p>
              <p>
                Our portfolio represents a curated collection of brands that are
                redefining aesthetic standards and consumer experiences
                globally. We partner with founders who possess a unique point of
                view and the ambition to build generational heritage brands.
              </p>
            </div>

            <div className="mt-12 pt-8 border-t border-charcoal/10">
              <div className="flex items-center space-x-12">
                <div>
                  <span className="block text-3xl font-serif text-rose mb-1">
                    $500M+
                  </span>
                  <span className="text-xs uppercase tracking-widest text-charcoal/60">
                    Assets Managed
                  </span>
                </div>
                <div>
                  <span className="block text-3xl font-serif text-rose mb-1">
                    12
                  </span>
                  <span className="text-xs uppercase tracking-widest text-charcoal/60">
                    Global Brands
                  </span>
                </div>
              </div>
            </div>
          </motion.div>

          {/* Image Content */}
          <motion.div
            initial={{
              opacity: 0,
              scale: 0.95
            }}
            whileInView={{
              opacity: 1,
              scale: 1
            }}
            viewport={{
              once: true,
              margin: '-100px'
            }}
            transition={{
              duration: 1,
              ease: 'easeOut'
            }}
            className="lg:col-span-6 order-1 lg:order-2 relative">

            <div className="aspect-[3/4] md:aspect-square lg:aspect-[4/5] overflow-hidden relative">
              <img
                src="https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&q=80&w=1000"
                alt="Editorial beauty portrait"
                className="w-full h-full object-cover" />

              <div className="absolute inset-0 border border-cream/20 m-4 md:m-8"></div>
            </div>
            {/* Decorative Element */}
            <div className="absolute -bottom-8 -left-8 w-32 h-32 bg-pink -z-10"></div>
          </motion.div>
        </div>
      </div>
    </section>);

}