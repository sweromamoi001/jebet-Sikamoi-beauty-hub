import React from 'react';
import { motion } from 'framer-motion';
const testimonials = [
{
  quote:
  'Beauté Ventures has an unparalleled eye for identifying the next generation of cult-favorite beauty brands before they hit the mainstream.',
  publication: 'Vogue Business'
},
{
  quote:
  'Their approach to brand building is meticulous, blending financial acumen with a deep respect for creative vision and aesthetic integrity.',
  publication: "Women's Wear Daily"
},
{
  quote:
  "The premier partner for beauty founders looking to scale without compromising their brand's luxury positioning or core values.",
  publication: 'Forbes'
}];

export function TestimonialsSection() {
  return (
    <section
      id="press"
      className="py-24 md:py-32 bg-charcoal text-cream overflow-hidden">

      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="text-center mb-20">
          <span className="text-xs uppercase tracking-[0.2em] text-gold mb-4 block">
            Recognition
          </span>
          <h2 className="text-4xl md:text-5xl font-serif">In The Press</h2>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-12 md:gap-8 lg:gap-16">
          {testimonials.map((item, index) =>
          <motion.div
            key={index}
            initial={{
              opacity: 0,
              y: 20
            }}
            whileInView={{
              opacity: 1,
              y: 0
            }}
            viewport={{
              once: true
            }}
            transition={{
              duration: 0.8,
              delay: index * 0.2
            }}
            className="flex flex-col items-center text-center relative">

              <span className="text-6xl font-serif text-gold/20 absolute -top-8 left-1/2 -translate-x-1/2">
                "
              </span>
              <p className="font-serif text-xl md:text-2xl leading-relaxed italic mb-8 relative z-10 text-cream/90">
                {item.quote}
              </p>
              <div className="mt-auto">
                <div className="w-8 h-[1px] bg-gold mx-auto mb-4"></div>
                <span className="text-sm uppercase tracking-widest text-gold">
                  {item.publication}
                </span>
              </div>
            </motion.div>
          )}
        </div>
      </div>
    </section>);

}