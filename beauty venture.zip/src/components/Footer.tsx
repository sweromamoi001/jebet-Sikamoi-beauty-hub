import React from 'react';
import { InstagramIcon, LinkedinIcon, TwitterIcon } from 'lucide-react';
export function Footer() {
  const currentYear = new Date().getFullYear();
  return (
    <footer className="bg-charcoal text-cream pt-20 pb-10 border-t border-cream/10">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-12 md:gap-8 mb-16">
          {/* Brand */}
          <div className="md:col-span-2">
            <a
              href="#"
              className="font-serif text-2xl tracking-widest text-cream block mb-6">

              BEAUTÉ VENTURES
            </a>
            <p className="text-cream/60 font-light text-sm max-w-sm leading-relaxed">
              Investing in the future of luxury beauty, skincare, and wellness.
              Building generational heritage brands through strategic
              partnership and operational excellence.
            </p>
          </div>

          {/* Links */}
          <div>
            <h4 className="text-xs uppercase tracking-[0.2em] text-gold mb-6">
              Navigation
            </h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="#about"
                  className="text-sm text-cream/70 hover:text-cream transition-colors">

                  About Us
                </a>
              </li>
              <li>
                <a
                  href="#portfolio"
                  className="text-sm text-cream/70 hover:text-cream transition-colors">

                  Portfolio
                </a>
              </li>
              <li>
                <a
                  href="#services"
                  className="text-sm text-cream/70 hover:text-cream transition-colors">

                  Services
                </a>
              </li>
              <li>
                <a
                  href="#press"
                  className="text-sm text-cream/70 hover:text-cream transition-colors">

                  Press
                </a>
              </li>
            </ul>
          </div>

          {/* Contact & Social */}
          <div>
            <h4 className="text-xs uppercase tracking-[0.2em] text-gold mb-6">
              Connect
            </h4>
            <ul className="space-y-4 mb-8">
              <li className="text-sm text-cream/70">
                Paris • New York • London
              </li>
              <li>
                <a
                  href="mailto:hello@beauteventures.com"
                  className="text-sm text-cream/70 hover:text-cream transition-colors">

                  hello@beauteventures.com
                </a>
              </li>
            </ul>
            <div className="flex space-x-4">
              <a
                href="#"
                className="text-cream/50 hover:text-gold transition-colors"
                aria-label="Instagram">

                <InstagramIcon className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-cream/50 hover:text-gold transition-colors"
                aria-label="LinkedIn">

                <LinkedinIcon className="w-5 h-5" />
              </a>
              <a
                href="#"
                className="text-cream/50 hover:text-gold transition-colors"
                aria-label="Twitter">

                <TwitterIcon className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="pt-8 border-t border-cream/10 flex flex-col md:flex-row justify-between items-center gap-4">
          <p className="text-xs text-cream/40">
            &copy; {currentYear} Beauté Ventures. All rights reserved.
          </p>
          <div className="flex space-x-6">
            <a
              href="#"
              className="text-xs text-cream/40 hover:text-cream transition-colors">

              Privacy Policy
            </a>
            <a
              href="#"
              className="text-xs text-cream/40 hover:text-cream transition-colors">

              Terms of Service
            </a>
          </div>
        </div>
      </div>
    </footer>);

}