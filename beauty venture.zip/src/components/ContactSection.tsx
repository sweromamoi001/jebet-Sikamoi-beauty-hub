import React from 'react';
import { motion } from 'framer-motion';
export function ContactSection() {
  return (
    <section id="contact" className="py-24 md:py-32 bg-cream">
      <div className="max-w-4xl mx-auto px-6 md:px-12 text-center">
        <motion.div
          initial={{
            opacity: 0,
            y: 30
          }}
          whileInView={{
            opacity: 1,
            y: 0
          }}
          viewport={{
            once: true
          }}
          transition={{
            duration: 0.8
          }}>

          <span className="text-xs uppercase tracking-[0.2em] text-rose mb-4 block">
            Inquiries
          </span>
          <h2 className="text-4xl md:text-5xl lg:text-6xl font-serif text-charcoal mb-8">
            Let's Create Something <br className="hidden md:block" />
            <span className="italic text-rose">Beautiful</span>
          </h2>
          <p className="text-charcoal/70 font-light mb-12 max-w-2xl mx-auto text-lg">
            Whether you are a founder seeking partnership or an investor looking
            to join our network, we welcome the conversation.
          </p>

          <form
            className="max-w-md mx-auto relative"
            onSubmit={(e) => e.preventDefault()}>

            <div className="flex flex-col sm:flex-row gap-4">
              <input
                type="email"
                placeholder="sijebet"
                className="flex-1 bg-transparent border-b border-charcoal/30 py-4 px-2 text-charcoal placeholder:text-charcoal/40 focus:outline-none focus:border-rose transition-colors rounded-none"
                required />

              <button
                type="submit"
                className="bg-charcoal text-cream px-8 py-4 uppercase tracking-widest text-sm hover:bg-rose transition-colors duration-300 sm:w-auto w-full">

                Get in Touch
              </button>
            </div>
          </form>
        </motion.div>
      </div>
    </section>);

}