import React from 'react';
import { motion } from 'framer-motion';
import {
  TrendingUpIcon,
  PaletteIcon,
  GlobeIcon,
  SparklesIcon } from
'lucide-react';
const services = [
{
  title: 'Strategic Investment',
  description:
  'Providing growth capital and strategic guidance to scale operations, expand product lines, and enter new markets with confidence.',
  icon: TrendingUpIcon
},
{
  title: 'Brand Development',
  description:
  'Refining brand positioning, visual identity, and storytelling to create deep, emotional connections with luxury consumers.',
  icon: PaletteIcon
},
{
  title: 'Global Distribution',
  description:
  'Leveraging our extensive network to secure premium retail placements and optimize direct-to-consumer channels worldwide.',
  icon: GlobeIcon
},
{
  title: 'Digital Innovation',
  description:
  'Implementing cutting-edge e-commerce solutions, digital marketing strategies, and data analytics to drive customer acquisition.',
  icon: SparklesIcon
}];

export function ServicesSection() {
  return (
    <section id="services" className="py-24 md:py-32 bg-pink/30">
      <div className="max-w-7xl mx-auto px-6 md:px-12">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
          {/* Header Column */}
          <div className="lg:col-span-4">
            <div className="sticky top-32">
              <span className="text-xs uppercase tracking-[0.2em] text-rose mb-4 block">
                Expertise
              </span>
              <h2 className="text-4xl md:text-5xl font-serif text-charcoal mb-6">
                How We <br className="hidden lg:block" />
                Partner
              </h2>
              <p className="text-charcoal/70 font-light leading-relaxed mb-8">
                We offer more than capital. Our team of industry veterans
                provides hands-on operational support to help founders navigate
                the complexities of the global beauty market.
              </p>
              <a
                href="#contact"
                className="inline-flex items-center text-sm uppercase tracking-widest text-charcoal hover:text-rose transition-colors group">

                Work With Us
                <span className="ml-2 w-6 h-[1px] bg-charcoal group-hover:bg-rose transition-colors"></span>
              </a>
            </div>
          </div>

          {/* Services Grid */}
          <div className="lg:col-span-8">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12">
              {services.map((service, index) => {
                const Icon = service.icon;
                return (
                  <motion.div
                    key={service.title}
                    initial={{
                      opacity: 0,
                      y: 30
                    }}
                    whileInView={{
                      opacity: 1,
                      y: 0
                    }}
                    viewport={{
                      once: true,
                      margin: '-50px'
                    }}
                    transition={{
                      duration: 0.6,
                      delay: index * 0.1
                    }}
                    className="bg-cream p-8 md:p-10 border border-charcoal/5 hover:border-rose/20 transition-colors duration-300">

                    <div className="w-12 h-12 rounded-full bg-pink flex items-center justify-center mb-8 text-rose">
                      <Icon className="w-5 h-5" strokeWidth={1.5} />
                    </div>
                    <h3 className="font-serif text-2xl text-charcoal mb-4">
                      {service.title}
                    </h3>
                    <p className="text-charcoal/70 font-light leading-relaxed text-sm md:text-base">
                      {service.description}
                    </p>
                  </motion.div>);

              })}
            </div>
          </div>
        </div>
      </div>
    </section>);

}